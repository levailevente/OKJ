﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace THE_GAME
{
    class animacio 
    {

        
       static int n=15;
        Sprite[] tomb=new Sprite[n];
        public animacio()
        {
            for (int i = 1; i < n; i++)
            {
                tomb[i]=new Sprite(C)
            }

        }


    }
}
